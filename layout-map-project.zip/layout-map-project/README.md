# Layout Plot Status

## Run Locally
Open `index.html` in your browser.

## Features
- Toggle Sold / Unsold plots
- Responsive layout
- Easy customization
